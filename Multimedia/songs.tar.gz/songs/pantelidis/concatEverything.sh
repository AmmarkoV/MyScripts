#!/bin/bash
rm all.lyrics
sleep 0.1
cat $@ > all.lyrics
exit 0
